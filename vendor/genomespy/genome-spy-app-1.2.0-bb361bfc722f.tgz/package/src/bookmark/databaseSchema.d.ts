import { DBSchema } from "idb";
import { ChromosomalLocus } from "@genome-spy/core/genome/genome.js";
import { ViewSettingsPayload } from "../state.js";
import { Action } from "../state/provenance.js";
import { SampleAttributePlotDefinition } from "../charts/sampleAttributePlotTypes.js";

export interface BookmarkPlotAttachment {
    kind: "sample_attribute_plot";
    definition: SampleAttributePlotDefinition;
}

export interface BookmarkEntry {
    name: string;

    notes?: string;

    /**
     * Provenance
     */
    actions?: Action[];

    /**
     * Domains of scales that are both zoomable and named
     */
    scaleDomains?: Record<string, number[] | ChromosomalLocus[]>;

    /**
     * Settings such as view visibilities
     */
    viewSettings?: ViewSettingsPayload;

    /**
     * Plots attached to the bookmark.
     */
    plots?: BookmarkPlotAttachment[];
}

export interface BookmarkDB extends DBSchema {
    bookmarks: {
        value: BookmarkEntry;
        key: string;
    };
}
