import {
    ConcatSpec as CoreConcatSpec,
    FacetSpec as CoreFacetSpec,
    HConcatSpec as CoreHConcatSpec,
    ImportSpec,
    LayerSpec as CoreLayerSpec,
    MultiscaleSpec as CoreMultiscaleSpec,
    UnitSpec as CoreUnitSpec,
    VConcatSpec as CoreVConcatSpec,
    SurroundSpec as CoreSurroundSpec,
    SurroundSideSpec as CoreSurroundSideSpec,
    Side,
} from "@genome-spy/core/spec/view.js";
import { SampleSpec } from "./sampleView.js";

// App has two view unions:
// - AppNestedViewSpec: legal in recursive positions (templates, children)
// - AppViewSpec: root-level union that can additionally include SampleSpec
//
// This prevents nested SampleSpecs while still allowing a SampleSpec under
// app-level concat roots.
export type AggregatingSpec = AppUnitSpec | AppLayerSpec;

export interface AggregateSamplesSpec {
    /**
     * Specifies views that [aggregate](https://genomespy.app/docs/sample-collections/visualizing/#aggregation)
     * multiple samples within the GenomeSpy App.
     */
    aggregateSamples?: AggregatingSpec[];
}

/**
 * App-only visibility setting exposed in the view visibility menu.
 */
export interface AppVisibilityGroupSpec {
    /**
     * Name of a mutually exclusive visibility group.
     *
     * Views with the same group name in the same import scope are controlled
     * with radio buttons in the view visibility menu.
     */
    group: string;
}

/**
 * App-only visibility setting exposed in the view visibility menu.
 */
export interface AppConfigurableVisibilitySpec {
    /**
     * Is the visibility configurable from the GenomeSpy App view visibility menu.
     *
     * Configurability requires an explicit view name that is unique in its import
     * scope.
     *
     * Set to an object with `group` to make configurable views mutually
     * exclusive in the menu (radio buttons) within the same import scope.
     *
     * __Default value:__ `false` for children of `layer`, `true` for others
     */
    configurableVisibility?: boolean | AppVisibilityGroupSpec;
}

export type AppUnitSpec = Omit<CoreUnitSpec, "aggregateSamples" | "templates"> &
    AppConfigurableVisibilitySpec &
    AggregateSamplesSpec & {
        // Re-thread templates to the app union so nested views can use app-only
        // fields (e.g. aggregateSamples), but still exclude nested SampleSpec.
        templates?: Record<string, AppNestedViewSpec>;
    };

export type AppLayerSpec = Omit<
    CoreLayerSpec,
    "layer" | "aggregateSamples" | "templates"
> &
    AppConfigurableVisibilitySpec &
    AggregateSamplesSpec & {
        templates?: Record<string, AppNestedViewSpec>;

        layer: (AppLayerSpec | AppUnitSpec | AppMultiscaleSpec | ImportSpec)[];
    };

export type AppMultiscaleSpec = Omit<
    CoreMultiscaleSpec,
    "multiscale" | "aggregateSamples" | "templates"
> &
    AppConfigurableVisibilitySpec &
    AggregateSamplesSpec & {
        templates?: Record<string, AppNestedViewSpec>;

        multiscale: (
            AppLayerSpec | AppUnitSpec | AppMultiscaleSpec | ImportSpec
        )[];
    };

export type AppVConcatSpec = Omit<CoreVConcatSpec, "templates" | "vconcat"> &
    AppConfigurableVisibilitySpec & {
        templates?: Record<string, AppNestedViewSpec>;

        vconcat: (AppViewSpec | ImportSpec)[];
    };

export type AppFacetSpec = Omit<CoreFacetSpec, "templates" | "spec"> &
    AppConfigurableVisibilitySpec & {
        templates?: Record<string, AppNestedViewSpec>;

        spec: AppLayerSpec | AppUnitSpec | ImportSpec;
    };

export type AppHConcatSpec = Omit<CoreHConcatSpec, "templates" | "hconcat"> &
    AppConfigurableVisibilitySpec & {
        templates?: Record<string, AppNestedViewSpec>;

        hconcat: (AppViewSpec | ImportSpec)[];
    };

export type AppConcatSpec = Omit<CoreConcatSpec, "templates" | "concat"> &
    AppConfigurableVisibilitySpec & {
        templates?: Record<string, AppNestedViewSpec>;

        concat: (AppViewSpec | ImportSpec)[];
    };

export type AppSurroundPlotSpec =
    AppUnitSpec | AppLayerSpec | AppMultiscaleSpec | ImportSpec;

export type AppSurroundSideSpec = Omit<
    CoreSurroundSideSpec,
    "templates" | "views"
> &
    AppConfigurableVisibilitySpec & {
        templates?: Record<string, AppNestedViewSpec>;
        views: (AppSurroundPlotSpec | AppSurroundSpec)[];
    };

export type AppSurroundSides = Partial<
    Record<
        Side,
        AppSurroundSideSpec | (AppSurroundPlotSpec | AppSurroundSpec)[]
    >
>;

export type AppSurroundSpec = Omit<
    CoreSurroundSpec,
    "templates" | "spec" | "surround"
> &
    AppConfigurableVisibilitySpec & {
        templates?: Record<string, AppNestedViewSpec>;
        spec: AppSurroundPlotSpec;
        surround: AppSurroundSides;
    };

export type AppNestedViewSpec =
    | AppUnitSpec
    | AppLayerSpec
    | AppMultiscaleSpec
    | AppFacetSpec
    | AppVConcatSpec
    | AppHConcatSpec
    | AppConcatSpec
    | AppSurroundSpec;

// App root may contain SampleSpec, but recursive descendants cannot.
export type AppViewSpec = AppNestedViewSpec | SampleSpec;
