/**
 * `agentApi` exposes App internals to the agent and plugin surfaces only.
 * Do not add App code here that the rest of App should depend on.
 *
 * `AgentApi` is the centralized handle for host state, provenance, and view
 * mutations that the extracted agent package may use.
 */
import type { Action } from "@reduxjs/toolkit";
import type {
    ActionInfo,
    AttributeIdentifier,
    AttributeInfo,
    AppRootSpec,
    AppState,
    ProvenanceAction,
    SampleHierarchy,
    ViewSelector,
} from "../agentShared/index.d.ts";
import type {
    SampleAttributePlot,
    SampleAttributePlotRequest,
    SampleAttributePlotType,
} from "../charts/sampleAttributePlotTypes.d.ts";
import type { ScaleResolutionApi } from "@genome-spy/core/types/scaleResolutionApi.js";
import type UnitView from "@genome-spy/core/view/unitView.js";

export interface AgentMetadataSourceIdentifierSummary {
    name: string;
    primary?: boolean;
    caseInsensitive?: boolean;
    stripVersionSuffix?: boolean;
    examples: string[];
}

export interface AgentMetadataSourceSummary {
    sourceId?: string;
    name?: string;
    description?: string;
    attributeDefaults?: {
        dataType?: string;
        description?: string;
    };
    identifiers: AgentMetadataSourceIdentifierSummary[];
}

export interface AgentApi {
    /**
     * Returns the current sample hierarchy used by the agent context.
     */
    getSampleHierarchy(): SampleHierarchy | undefined;

    getMetadataSourceSummaries(
        signal?: AbortSignal
    ): Promise<AgentMetadataSourceSummary[]>;

    getAttributeInfo(attribute: AttributeIdentifier): AttributeInfo | undefined;

    /**
     * Resolves live selection-backed intervals inside an attribute identifier to
     * literal intervals for formatting and durable features.
     */
    materializeAttributeIdentifier(
        attribute: AttributeIdentifier
    ): AttributeIdentifier;

    /**
     * Returns the current SampleView-scoped param config.
     *
     * TODO(app): Make this unscoped and accept a `ParamSelector` once the
     * agent boundary no longer needs the SampleView-local lookup.
     */
    getSampleViewScopedParamConfig(
        paramName: string
    ): { description?: string } | undefined;

    getDatumSearch(): import("@genome-spy/core/types/search.js").DatumSearch;
    getViewApi(): import("@genome-spy/core/types/embedApi.js").ViewApi;
    getSearchableViews(): UnitView[];

    getViewRoot(): import("@genome-spy/core/view/view.js").default | undefined;

    /**
     * Returns the current focus view for tree normalization and expansion.
     * This is typically the current sample view.
     */
    getFocusedView():
        import("@genome-spy/core/view/view.js").default | undefined;

    /**
     * Returns the root spec used to summarize the top-level visualization.
     */
    getRootSpec(): AppRootSpec;

    getNamedScaleResolutions(): Map<string, ScaleResolutionApi>;

    resolveViewSelector(
        selector: ViewSelector
    ): import("@genome-spy/core/view/view.js").default | undefined;

    getSelectionFeatureFieldValues(
        viewSelector: ViewSelector,
        selectionSelector: import("@genome-spy/core/view/viewSelectors.js").ParamSelector,
        field: string
    ): unknown[] | undefined;

    /**
     * Returns the provenance actions currently available to the agent.
     */
    getActionHistory(): ProvenanceAction[];

    getActionInfo(action: Action): ActionInfo | undefined;

    /**
     * Submits a prepared set of actions to the app intent pipeline.
     */
    submitIntentActions(
        actions: Action[],
        options?: { submissionKind?: "agent" | "bookmark" | "user" }
    ): Promise<void>;

    /**
     * Returns the current provenance state used by selection and timeline tools.
     */
    getPresentProvenanceState(): AppState["provenance"]["present"] | undefined;

    buildSampleAttributePlot(
        request: SampleAttributePlotRequest
    ): Promise<SampleAttributePlot | undefined>;

    setViewVisibility(selector: ViewSelector, visibility: boolean): void;

    jumpToProvenanceState(provenanceId: string): boolean;

    jumpToInitialProvenanceState(): boolean;
}

export type {
    SampleAttributePlot,
    SampleAttributePlotRequest,
    SampleAttributePlotType,
};

export declare function embedRenderablePlot(
    container: HTMLElement,
    plot: SampleAttributePlot
): Promise<import("@genome-spy/core/types/embedApi.js").EmbedResult>;

export declare function createAgentApi(app: any): AgentApi;
