declare module "vega-loader";
